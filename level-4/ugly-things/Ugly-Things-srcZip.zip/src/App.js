import React from 'react'
import Form from './Form'
import ImagesDisplay from './ImagesDisplay'


function App(){
    return(
        <div>
            <h1>Ugly Things</h1>

            <Form />
            <ImagesDisplay />
    
        </div>
    )
}

export default App